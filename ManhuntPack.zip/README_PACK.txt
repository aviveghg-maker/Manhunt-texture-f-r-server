MANHUNT RESOURCE-PACK (fuer Minecraft 1.21.4, pack_format 46)

Eigene Icons: einfach die PNGs in assets/manhunt/textures/item/ ersetzen (16x16 oder 32x32):
  menu.png      Manhunt-Menue (Nether-Stern, CustomModelData 1001)
  tutorial.png  Tutorial (Buch, 1002)
  top.png       Leaderboard (Goldbarren, 1003)
  play.png      Lobby/Start (Smaragd, 1005)

Eigene Schrift (wie auf anderen Servern): assets/minecraft/font/default.json anlegen
und eine eigene Schrift einbinden. Das Plugin muss dafuer nicht geaendert werden.

Neue ZIP bauen: den INHALT dieses Ordners (pack.mcmeta, pack.png, assets) zippen,
sodass pack.mcmeta direkt im ZIP-Hauptordner liegt.
Dann hochladen (z.B. eigener Webspace/GitHub Release), URL und SHA-1 in config.yml bei
resource-pack: eintragen. SHA-1 auf Windows: certutil -hashfile ManhuntPack.zip SHA1
